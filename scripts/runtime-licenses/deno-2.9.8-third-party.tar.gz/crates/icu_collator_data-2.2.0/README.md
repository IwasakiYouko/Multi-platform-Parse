# icu_collator_data [![crates.io](https://img.shields.io/crates/v/icu_collator_data)](https://crates.io/crates/icu_collator_data)

<!-- cargo-rdme start -->

Data for the `icu_collator` crate

This data was generated with CLDR version 48.2.0, ICU version release-78.1rc, and
LSTM segmenter version v0.1.0.

<!-- cargo-rdme end -->

## More Information

For more information on development, authorship, contributing etc. please visit [`ICU4X home page`](https://github.com/unicode-org/icu4x).
