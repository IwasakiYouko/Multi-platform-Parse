# rust-cfb

[![Build Status](https://github.com/mdsteele/rust-cfb/actions/workflows/tests.yml/badge.svg)](https://github.com/mdsteele/rust-cfb/actions/workflows/tests.yml)
[![Crates.io](https://img.shields.io/crates/v/cfb.svg)](https://crates.io/crates/cfb)
[![Documentation](https://docs.rs/cfb/badge.svg)](https://docs.rs/cfb)

A Rust library for reading/writing [Compound File Binary](
https://en.wikipedia.org/wiki/Compound_File_Binary_Format) (structured storage)
files. See [MS-CFB](https://msdn.microsoft.com/en-us/library/dd942138.aspx)
for the format specification.

## License

rust-cfb is made available under the
[MIT License](http://spdx.org/licenses/MIT.html).

## Development

This project uses [Cargo](https://doc.rust-lang.org/cargo/) as its build system
and package manager.

### Tests

```bash
cargo test
```

### Benchmarks

There is a benchmark suite using [Criterion.rs](https://github.com/bheisler/criterion.rs). To run the benchmarks:

```bash
cargo bench
```

For a clean run (reset Criterion stats), delete the Criterion output directory and re-run:

```bash
rm -rf target/criterion
cargo bench
```


